//package com.example.demo.services;
//
//import com.example.demo.models.User;
//import org.springframework.stereotype.Service;
//import java.util.ArrayList;
//import java.util.List;
//
//@Service
//public class UserService {
//
//
//    private List<User> users = new ArrayList<>();
//
//    public List<User> getAllUsers() {
//        return users;
//    }
//
//    public User registerUser(User user) {
//        users.add(user);
//        return user;
//    }
//
//    public User loginUser(String username, String password) {
//        return null;
//    }
//
//
//
//}
