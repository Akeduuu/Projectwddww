import React from 'react';
import BooksList from './BookList';
import CategoriesList from './CategoriesList';

const AdminPanel = () => {
  return (
    <div>
      <h1>Admin Panel</h1>
      <div>
        <BooksList />
        <CategoriesList />
      </div>
    </div>
  );
};

export default AdminPanel;
