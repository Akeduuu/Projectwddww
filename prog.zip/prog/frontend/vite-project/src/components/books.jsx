import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../css/Books.css'

function App() {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [year, setYear] = useState('');
  const [books, setBooks] = useState([]);
  const [error, setError] = useState('');


  const fetchBooks = async () => {
    try {
      const response = await axios.get('http://localhost:9090/api/books');
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
      setError('Failed to fetch books');
    }
  };


  useEffect(() => {
    fetchBooks();
  }, []);

  const handleCreateBook = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:9090/api/books', { title, author, year });
      if (response.data && response.data.title && response.data.author && response.data.year) {
        alert(`Book created: ${response.data.title} by ${response.data.author} , ${response.data.year} year`);
        setTitle('');
        setAuthor('');
        setYear('');

        fetchBooks();
      } else {
        setError('Failed to create book');
      }
    } catch (error) {
      console.error('Error creating book:', error);
      setError('Failed to create book');
    }
  };

  return (
    <div>
      <h1>Book Management</h1>
      <form onSubmit={handleCreateBook}>
        <label htmlFor="title">Title:</label>
        <input type="text" id="title" value={title} onChange={(event) => setTitle(event.target.value)} /><br /><br />
        <label htmlFor="author">Author:</label>
        <input type="text" id="author" value={author} onChange={(event) => setAuthor(event.target.value)} /><br /><br />
        <label htmlFor="year">Year:</label>
        <input type="number" id="Year" value={year} onChange={(event) => setYear(event.target.value)} /><br /><br />
        <button type="submit">Create Book</button>
      </form>
      {error && <p>{error}</p>}
      <h2>Books</h2>
      <ul>
      
        {books.map((book) => (
            <div >
          <li className='SettingInfo' key={book.id}>
            {book.title && book.author && book.year ? `${book.title} by ${book.author} , ${book.year} year` : 'Invalid book data'}
          </li>
          </div>
        ))}
      
      </ul>
    </div>
  );
}

export default App;

